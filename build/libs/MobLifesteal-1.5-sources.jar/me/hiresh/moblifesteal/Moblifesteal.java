package me.hiresh.moblifesteal;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.class_1280;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1569;
import net.minecraft.class_1934;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_5134;
import net.minecraft.class_8103;

public class Moblifesteal implements ModInitializer {

    @Override
    public void onInitialize() {
        //If a player is damaged by the entity, grant the entity the hearts and take from the player
        ServerLivingEntityEvents.ALLOW_DAMAGE.register(((livingEntity, damageSource, amount) -> {
            if(livingEntity instanceof class_3222 player) {
                float finalDamage = class_1280.method_5496(livingEntity, amount, damageSource, player.method_6096(), (float)player.method_45325(class_5134.field_23725));

                if (player.method_6039() && !damageSource.method_48789(class_8103.field_56242)){
                    //Check if player is shielding against the damage
                    class_243 srcPos = damageSource.method_5510();
                    if (srcPos != null){
                        class_243 viewVec = player.method_5720();
                        class_243 srcVec = srcPos.method_1020(player.method_73189()).method_1029();

                        if (srcVec.method_1026(viewVec) < 0.0f){
                            return true;
                        }
                    }

                    return true; //Ignore if shielding
                }

                if (!(damageSource.method_5529() instanceof class_1309)) {
                    return true; //Handle vanilla if not a mob causing the damage
                }

                StealHearts(player, damageSource, finalDamage);

                //Send damage flags, sound and then do not apply damage as already applied on StealHearts()
                player.method_51469().method_8421(player, (byte)2);
                player.method_51469().method_43128(
                        null,
                        player.method_23317(),
                        player.method_23318(),
                        player.method_23321(),
                        class_3417.field_15115,
                        player.method_5634(),
                        1.0f,
                        1.0f
                );
                return false;
            }
            return true; //Vanilla handling given any other scenario
        }));

        //If a player kills a hostile entity grant the player a heart
        ServerLivingEntityEvents.AFTER_DEATH.register((livingEntity, damageSource) -> {
            if(damageSource.method_5529() instanceof class_3222 player) {
                if (!(livingEntity instanceof class_1569 monster)) return; //Only if hostile entity
                GivePlayerHeart(player);
            }
        });


    }

    public void StealHearts(class_3222 player, class_1282 damageSource, float damageAmount) {
        if (player == null) return;
        var playerMaxHealthAttribute = player.method_5996(class_5134.field_23716);
        if (playerMaxHealthAttribute == null) return;

        //Take health from player / "ban" the player
        float currentMax = player.method_6063();
        float currentHealth = player.method_6032();
        if (currentMax < damageAmount) {
            //Set to spectator, reset health and send a message to notify them that they lost.
            player.method_7336(class_1934.field_9219);
            playerMaxHealthAttribute.method_6192(20.0f);
            player.method_6033(20.0f);
            player.method_64398(class_2561.method_43470("§cYou have lost all of your hearts! Game over."));
        } else {
            //Remove the hearts from max health
            playerMaxHealthAttribute.method_6192(currentMax - damageAmount);

            player.method_6033(currentHealth - damageAmount);
        }

        //Give the lost hearts to the attacking mob
        if (damageSource.method_5529() instanceof class_1309 attacker) {
            var mobMaxHealthAttribute = attacker.method_5996(class_5134.field_23716);
            if (mobMaxHealthAttribute == null) return;
            double currentMobMax = mobMaxHealthAttribute.method_6201();

            //Set max mob health
            mobMaxHealthAttribute.method_6192(currentMobMax + damageAmount);

            //Add the additional hearts as well
            attacker.method_6025(damageAmount);
        }
    }

    public void GivePlayerHeart(class_3222 player) {
        if (player == null) return;
        var maxHealthAttribute = player.method_5996(class_5134.field_23716);
        if (maxHealthAttribute == null) return;

        //Increase max health by a heart
        maxHealthAttribute.method_6192(maxHealthAttribute.method_6201() + 2.0f);
        if (maxHealthAttribute.method_6201() > 20.0f){
            maxHealthAttribute.method_6192(20.0f);
        }

        //Increase current health by a heart
        player.method_6025(2.0f);

    }
}
