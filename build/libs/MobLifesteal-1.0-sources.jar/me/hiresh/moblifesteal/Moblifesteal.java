package me.hiresh.moblifesteal;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1934;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_5134;

public class Moblifesteal implements ModInitializer {

    @Override
    public void onInitialize() {
        ServerLivingEntityEvents.ALLOW_DAMAGE.register(((livingEntity, damageSource, amount) -> {
            if(livingEntity instanceof class_3222 player) {
                StealHearts(player, damageSource, amount);
            }
            return true;
        }));

        ServerLivingEntityEvents.AFTER_DEATH.register((livingEntity, damageSource) -> {
            if(damageSource.method_5529() instanceof class_3222 player) {
                GivePlayerHeart(player);
            }
        });
    }

    public void StealHearts(class_3222 player, class_1282 damageSource, float damageAmount) {
        if (player == null) return;
        var playerMaxHealthAttribute = player.method_5996(class_5134.field_23716);
        if (playerMaxHealthAttribute == null) return;

        //Take health from player / "ban" the player
        float currentMax = player.method_6063();
        if (currentMax < damageAmount) {
            //Set to spectator, reset health and send a message to notify them that they lost.
            player.method_7336(class_1934.field_9219);
            playerMaxHealthAttribute.method_6192(20.0f);
            player.method_6033(20.0f);
            player.method_64398(class_2561.method_43470("§cYou have lost all of your hearts! Game over."));
        } else {
            //Remove the hearts from max health
            playerMaxHealthAttribute.method_6192(currentMax - damageAmount);

            //In the case this decreases the max health below the player's health, set the health to max
            if(player.method_6032() > player.method_6063()) {
                player.method_6033(player.method_6063());
            }
        }

        //Give the lost hearts to the attacking mob
        if (damageSource.method_5529() instanceof class_1309 attacker) {
            var mobMaxHealthAttribute = attacker.method_5996(class_5134.field_23716);
            if (mobMaxHealthAttribute == null) return;
            double currentMobMax = mobMaxHealthAttribute.method_6201();

            //Set max mob health
            mobMaxHealthAttribute.method_6192(currentMobMax + damageAmount);

            //Add the additional hearts as well
            attacker.method_6025(damageAmount);
        }
    }

    public void GivePlayerHeart(class_3222 player) {
        if (player == null) return;
        var maxHealthAttribute = player.method_5996(class_5134.field_23716);
        if (maxHealthAttribute == null) return;

        //Increase max health by a heart
        maxHealthAttribute.method_6192(maxHealthAttribute.method_6201() + 2.0f);
        if (maxHealthAttribute.method_6201() > 20.0f){
            maxHealthAttribute.method_6192(20.0f);
        }

        //Increase current health by a heart
        player.method_6025(2.0f);

    }
}
